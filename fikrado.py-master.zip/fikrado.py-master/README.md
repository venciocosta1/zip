
<p align="center">
  <h1 align="center">FIKRADO.PY THE FACEBOOK HACKINGN TOOL</h1>
</p>



[![Github](https://img.shields.io/badge/Github-fikrado-yellow?style=for-the-badge&logo=github)](https://github.com/fikrado)
[![Instagram](https://img.shields.io/badge/IG-%40mr__yahye-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/mr__yahe)
[![Messenger](https://img.shields.io/badge/telegram-blue?style=for-the-badge&logo=telegram)](https://t.me/fikrado_hacker)
[![Facebook](https://img.shields.io/badge/facebook-black?style=for-the-badge&logo=Facebook)](https://facebook.com/fikrado4048063)
[![Twitter](https://img.shields.io/badge/Twitter-purple?style=for-the-badge&logo=Twitter)](https://twitter.com/fikrado1)

<p align="center">
 <img height="250" src="fp.png" >
</p>


[![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com)  [![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)


<h4>
This tool created for hacking  multibul facebook accounts useing the facebook api if want to hack a lot of facebook accounts this your tool 
you can use this tool on any python 2.7 installed divice like linux, windows, termux and ish
for more information thanks to tgeniusclub to full docmented the tool at this blog https://tgeniusclub.com/fikrado-py-the-facebook-hacking-tool/
or use it on goole cloude by click on the bottom below and remember to download the dependence 
</h4>

[![Open in Cloud Shell](https://user-images.githubusercontent.com/27065646/92304704-8d146d80-ef80-11ea-8c29-0deaabb1c702.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/fikrado/fikrado.py&tutorial=README.md) 


### PLEASE DONATE 
<h5>
patreon https://patreon.com/fikrado
liberapay https://liberapay.com/fikrado
</h5>

____________

## [+] Termux Installation
#### install this tool in termux with this comands
```

git clone https://github.com/fikrado/fikrado.py

cd fikrado.py

bash termux.sh

python2 fikrado.py

```

____________

### [+]Andiroid Termux ScreenShot
<img width="100px" src="/PicsArt_09-11-08.26.12.jpg">

## [+] kali installation
#### you can install this tool in kali or any linux device with this commands
_______________
```


git clone https://github.com/fikrado/fikrado.py

cd fikrado.py

bash kali.sh

python2 fikrado.py

```
### [+] Kali Linux ScreenShot

<img width="750px" src="s1.png">


