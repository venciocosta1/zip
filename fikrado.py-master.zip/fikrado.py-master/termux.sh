#!/bin/bash
echo "downloading python2 for hackers"
apt install python2
echo "downloading pip requrement"
pip2 install mechanize requests
python2 fikrado.py